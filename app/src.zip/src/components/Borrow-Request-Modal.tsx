// src/components/Borrow-Request-Modal.tsx
'use client'

import { FC, useState } from 'react'
import {
  Dialog,
  DialogTrigger,
  DialogOverlay,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'

export interface P2PRow {
  lender: string
  orders: number
  completion: string
  likeRate: string
  offerAmount: string // e.g. "5,000 XRP"
  offerUSDT: string // e.g. "10,000 USDT"
  collateralCoin: string // e.g. "BTC"
  collateralMin: string // e.g. "0.16 BTC"
  collateralUSDT: string // e.g. "10,240 USDT"
}

interface BorrowRequestModalProps {
  row: P2PRow
  open: boolean
  onOpenChange: (open: boolean) => void
  onRequest: (borrowAmt: number, collateralAmt: number) => void
}

export const BorrowRequestModal: FC<BorrowRequestModalProps> = ({ row, open, onOpenChange, onRequest }) => {
  const totalSupplyNum = parseFloat(row.offerAmount.replace(/,/g, ''))
  const [borrowAmt, setBorrowAmt] = useState<number>(0)
  const [collateralAmt, setCollateralAmt] = useState<number>(0)
  const totalBorrowed = 0
  const supplyLeft = totalSupplyNum - totalBorrowed

  const rates: Record<string, number> = {
    USDC: 1,
    USDT: 1,
    BTC: 50000,
    ETH: 4000,
    SOL: 100,
    XRP: 0.5,
  }
  const collRate = rates[row.collateralCoin] || 0
  const collEq = (collateralAmt * collRate).toFixed(2)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        {/* <-- Updated trigger button styling */}
        <Button
          size="sm"
          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-sm text-white rounded-lg transition"
        >
          Borrow
        </Button>
      </DialogTrigger>

      <DialogOverlay className="fixed inset-0 bg-black/60" />

      <DialogContent className="fixed left-1/2 top-1/2 max-w-md w-[90vw] max-h-[80vh] -translate-x-1/2 -translate-y-1/2 bg-slate-800 rounded-2xl p-6 shadow-xl overflow-auto">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold text-white">Borrow from {row.lender}</DialogTitle>
        </DialogHeader>

        {/* Stats */}
        <div className="mt-4 space-y-2 text-sm text-slate-200">
          <div>
            <span className="font-medium text-white">Total Supply:</span> {row.offerAmount}
          </div>
          <div>
            <span className="font-medium text-white">Total Borrowed:</span> {totalBorrowed.toLocaleString()}{' '}
            {row.offerAmount.split(' ').pop()}
          </div>
          <div>
            <span className="font-medium text-white">Supply Left:</span> {supplyLeft.toLocaleString()}{' '}
            {row.offerAmount.split(' ').pop()}
          </div>
        </div>

        {/* Borrow Amount */}
        <div className="mt-6">
          <Label htmlFor="borrowAmt" className="text-slate-300">
            Borrow Amount
          </Label>
          <Input
            id="borrowAmt"
            type="number"
            value={borrowAmt || ''}
            onChange={(e) => setBorrowAmt(parseFloat(e.target.value))}
            placeholder={String((supplyLeft * 0.01).toFixed(2))}
            className="mt-1 w-full bg-slate-700 border-slate-600 text-white"
          />
          <p className="text-xs text-slate-400 mt-1">
            Min: {(supplyLeft * 0.01).toFixed(2)} {row.offerAmount.split(' ').pop()}
          </p>
        </div>

        {/* Collateral */}
        <div className="mt-4">
          <Label htmlFor="collateralToken" className="text-slate-300">
            Collateral Token
          </Label>
          <Input
            id="collateralToken"
            readOnly
            value={row.collateralCoin}
            className="mt-1 w-full bg-slate-700 border-slate-600 text-white cursor-not-allowed"
          />

          <Label htmlFor="collateralAmt" className="text-slate-300 mt-4">
            Collateral Amount
          </Label>
          <Input
            id="collateralAmt"
            type="number"
            value={collateralAmt || ''}
            onChange={(e) => setCollateralAmt(parseFloat(e.target.value))}
            placeholder={row.collateralMin.split(' ')[0]}
            className="mt-1 w-full bg-slate-700 border-slate-600 text-white"
          />
          <p className="text-xs text-slate-400 mt-1">≈ ${isNaN(Number(collEq)) ? '0.00' : collEq} USDT</p>
        </div>

        <DialogFooter className="mt-6">
          <Button
            className="w-full bg-gradient-to-r from-sky-400 to-blue-600 text-white rounded-lg"
            onClick={() => {
              onRequest(borrowAmt, collateralAmt)
              onOpenChange(false)
            }}
            disabled={borrowAmt <= 0 || collateralAmt <= 0}
          >
            Request
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
