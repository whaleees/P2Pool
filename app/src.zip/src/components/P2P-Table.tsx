// src/components/P2PTable.tsx
'use client'

import React, { useState, useEffect } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { supabase } from '@/lib/supabaseClient'
import { BorrowRequestModal, P2PRow } from './Borrow-Request-Modal'

export default function P2PTable() {
  const PAGE_SIZE = 10

  // current page (0-indexed)
  const [page, setPage] = useState(0)
  // the slice of offers for this page
  const [offers, setOffers] = useState<P2PRow[]>([])
  // total number of rows in p2p_offers
  const [total, setTotal] = useState(0)
  // loading flag
  const [loading, setLoading] = useState(false)
  // modal state
  const [active, setActive] = useState<P2PRow | null>(null)

  // fetch whenever page changes
  useEffect(() => {
    let isCancelled = false
    async function loadPage() {
      setLoading(true)
      // calculate range
      const from = page * PAGE_SIZE
      const to = from + PAGE_SIZE - 1
      // pull with a count
      const { data, error, count } = await supabase
        .from('p2p_offers')
        .select('*', { count: 'exact' })
        .order('created_at', { ascending: false })
        .range(from, to)

      if (!isCancelled) {
        if (error) {
          console.error('Error loading P2P offers:', error)
        } else {
          setOffers(data ?? [])
          if (typeof count === 'number') setTotal(count)
        }
        setLoading(false)
      }
    }

    loadPage()
    return () => {
      isCancelled = true
    }
  }, [page])

  const totalPages = Math.ceil(total / PAGE_SIZE)

  return (
    <div className="w-full mt-10">
      {/* Header */}
      <div className="flex justify-between px-6 py-3 text-slate-400 text-xs font-semibold uppercase">
        <div className="flex-1">Lender</div>
        <div className="flex-1 text-right">Lending Offer</div>
        <div className="flex-1 text-right">Collateral Required</div>
        <div className="flex-1 text-right">Action</div>
      </div>

      {/* Loading State */}
      {loading && <div className="text-center text-slate-400 py-8">Loading…</div>}

      {/* Rows */}
      {!loading &&
        offers.map((row) => (
          <div
            key={row.id}
            className="flex items-center justify-between bg-slate-800 hover:bg-slate-700 rounded-2xl p-4 mt-2 transition"
          >
            <div className="flex-1 text-white">
              <div className="font-semibold">{row.lender}</div>
              <div className="text-xs text-slate-400 mt-1">
                {row.total_orders} orders | {row.completion} completion
              </div>
              <div className="text-xs text-green-400">👍{row.like_rate}</div>
            </div>

            <div className="flex-1 text-right text-white">
              <div className="font-semibold">
                {row.offer_amount.toLocaleString()} {row.offer_token}
              </div>
              <div className="text-xs text-slate-400 mt-1">≈ {row.offer_usdt.toLocaleString()} USDT</div>
            </div>

            <div className="flex-1 text-right text-white">
              <div className="font-semibold">{row.collateral_token}</div>
              <div className="text-xs text-slate-400 mt-1">
                Min: {row.collateral_min.toFixed(2)} ≈ {row.collateral_usdt.toFixed(2)} USDT
              </div>
            </div>

            <div className="flex-1 flex justify-end">
              <BorrowRequestModal
                row={row}
                open={active?.id === row.id}
                onOpenChange={(o) => setActive(o ? row : null)}
                onRequest={async (amt, coll) => {
                  // your insert into pending_requests & transaction_log here…
                  console.log('REQUEST BORROW', row.lender, amt, coll)
                }}
              />
            </div>
          </div>
        ))}

      {/* Pagination Controls */}
      <div className="flex items-center justify-center gap-4 mt-6">
        <button
          onClick={() => setPage((p) => Math.max(p - 1, 0))}
          disabled={page === 0}
          className="p-1 bg-slate-700 hover:bg-slate-600 disabled:opacity-50 rounded-full transition"
          aria-label="Previous"
        >
          <ChevronLeft className="w-5 h-5 text-slate-400" />
        </button>

        <span className="text-slate-400 text-sm">
          Page {page + 1} of {totalPages}
        </span>

        <button
          onClick={() => setPage((p) => Math.min(p + 1, totalPages - 1))}
          disabled={page >= totalPages - 1}
          className="p-1 bg-slate-700 hover:bg-slate-600 disabled:opacity-50 rounded-full transition"
          aria-label="Next"
        >
          <ChevronRight className="w-5 h-5 text-slate-400" />
        </button>
      </div>
    </div>
  )
}
